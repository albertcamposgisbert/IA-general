# TC - RACSO

## Teoria de la Computació 

| ID  | Nom complet | Parcial |
|:---:|:-----------:|:-------:|
|**DFA**| Deterministic Finite Automata | 1
|**REG**| Regular Operations | 1
|**CFG**| Context-Free Grammars | 2
|**PDA**| Push-Down Automata | 2
|**K**| Reductions | 3
|**WP**| Word Problem (Reachability) | 3
|**RCFG**| Reductions of CFG | 3
|**EXM**| Past Exams | 1, 2, 3|